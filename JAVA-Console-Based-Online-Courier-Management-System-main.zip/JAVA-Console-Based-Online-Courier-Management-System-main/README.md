# JAVA-Console-Based-Online-Courier-Management-System

A console based project developed for the Object Oriented Programming 1 (JAVA) course for the Summer 2019-2020 semester.
